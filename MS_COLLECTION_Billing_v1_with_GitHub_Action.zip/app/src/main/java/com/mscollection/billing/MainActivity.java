package com.mscollection.billing;

import android.Manifest;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    private LinearLayout root, itemsBox;
    private EditText customer, phone, itemName, qty, rate;
    private TextView totalText, printerStatus, billNoText;
    private BluetoothAdapter btAdapter;
    private BluetoothSocket socket;
    private OutputStream out;
    private SharedPreferences prefs;
    private long billNo;
    private final ArrayList<Item> items = new ArrayList<>();

    static class Item {
        String name; double qty, rate;
        Item(String n,double q,double r){name=n;qty=q;rate=r;}
        double total(){return qty*rate;}
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("billing", MODE_PRIVATE);
        billNo = prefs.getLong("billNo", 1);
        btAdapter = BluetoothAdapter.getDefaultAdapter();
        buildUi();
        requestBtPermission();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,20,24,28);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = tv("MS COLLECTION", 26, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        billNoText = tv("Bill No: " + billNo, 16, true);
        root.addView(billNoText);

        customer = edit("Customer Name");
        phone = edit("Mobile Number");
        phone.setInputType(InputType.TYPE_CLASS_PHONE);
        root.addView(customer); root.addView(phone);

        TextView itemTitle = tv("ADD ITEM", 18, true);
        root.addView(itemTitle);

        itemName = edit("Item Name");
        qty = edit("Qty");
        qty.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        rate = edit("Rate");
        rate.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        root.addView(itemName); root.addView(qty); root.addView(rate);

        Button add = btn("＋ Add Item");
        add.setOnClickListener(v -> addItem());
        root.addView(add);

        itemsBox = new LinearLayout(this);
        itemsBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(itemsBox);

        totalText = tv("TOTAL: ₹0.00", 22, true);
        totalText.setGravity(Gravity.RIGHT);
        root.addView(totalText);

        printerStatus = tv("Printer: Not Connected", 16, true);
        root.addView(printerStatus);

        Button connect = btn("🔵 Connect MPT-II Bluetooth Printer");
        connect.setOnClickListener(v -> choosePrinter());
        root.addView(connect);

        Button test = btn("🖨 Test Print");
        test.setOnClickListener(v -> testPrint());
        root.addView(test);

        Button print = btn("🧾 PRINT BILL");
        print.setOnClickListener(v -> printBill());
        root.addView(print);

        Button newBill = btn("＋ NEW BILL");
        newBill.setOnClickListener(v -> newBill());
        root.addView(newBill);

        TextView note = tv("Offline billing • No ads • No subscription\n58mm ESC/POS • MPT-II Bluetooth", 14, false);
        note.setGravity(Gravity.CENTER);
        root.addView(note);
    }

    private TextView tv(String s,int size,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size);
        t.setPadding(0,10,0,10);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }

    private EditText edit(String hint){
        EditText e=new EditText(this); e.setHint(hint); e.setTextSize(16);
        e.setSingleLine(true); e.setPadding(12,8,12,8);
        return e;
    }

    private Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(15);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(0,8,0,8); b.setLayoutParams(p); return b;
    }

    private void addItem(){
        String n=itemName.getText().toString().trim();
        if(n.isEmpty()){toast("Item name डालें");return;}
        double q=parse(qty.getText().toString(),1);
        double r=parse(rate.getText().toString(),0);
        if(r<=0){toast("Rate डालें");return;}
        items.add(new Item(n,q,r));
        refreshItems();
        itemName.setText(""); qty.setText(""); rate.setText("");
    }

    private void refreshItems(){
        itemsBox.removeAllViews();
        int i=1;
        double total=0;
        for(Item x:items){
            LinearLayout row=new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            TextView t=tv(i+++". "+x.name+"  "+x.qty+" × ₹"+money(x.rate)+" = ₹"+money(x.total()),15,false);
            row.addView(t,new LinearLayout.LayoutParams(0,-2,1));
            Button del=new Button(this); del.setText("X");
            final int idx=i-2;
            del.setOnClickListener(v->{items.remove(idx);refreshItems();});
            row.addView(del);
            itemsBox.addView(row);
            total+=x.total();
        }
        totalText.setText("TOTAL: ₹"+money(total));
    }

    private double parse(String s,double d){try{return Double.parseDouble(s);}catch(Exception e){return d;}}
    private String money(double d){return String.format(Locale.US,"%.2f",d);}

    private void requestBtPermission(){
        if(Build.VERSION.SDK_INT>=31 &&
          checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},100);
        }
    }

    private void choosePrinter(){
        if(btAdapter==null){toast("इस मोबाइल में Bluetooth नहीं है");return;}
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){
            requestBtPermission(); return;
        }
        if(!btAdapter.isEnabled()){
            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),200);
            return;
        }
        Set<BluetoothDevice> paired=btAdapter.getBondedDevices();
        ArrayList<BluetoothDevice> list=new ArrayList<>(paired);
        if(list.isEmpty()){toast("पहले Android Bluetooth Settings में MPT-II pair करें");return;}
        String[] names=new String[list.size()];
        for(int i=0;i<list.size();i++) names[i]=list.get(i).getName()+"\n"+list.get(i).getAddress();
        new AlertDialog.Builder(this).setTitle("Paired Printer चुनें")
          .setItems(names,(d,which)->connect(list.get(which))).show();
    }

    private void connect(BluetoothDevice device){
        new Thread(()->{
            try{
                if(socket!=null) try{socket.close();}catch(Exception ignored){}
                socket=device.createRfcommSocketToServiceRecord(
                    UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
                socket.connect();
                out=socket.getOutputStream();
                runOnUiThread(()->printerStatus.setText("Printer: Connected • "+device.getName()));
            }catch(Exception e){
                runOnUiThread(()->toast("Connection failed: "+e.getMessage()));
            }
        }).start();
    }

    private boolean ensureConnected(){
        if(socket!=null && socket.isConnected() && out!=null)return true;
        toast("पहले MPT-II printer connect करें"); return false;
    }

    private void testPrint(){
        if(!ensureConnected())return;
        new Thread(()->{
            try{
                esc("@");
                esc("a",1); esc("E",1); text("MS COLLECTION\n"); esc("E",0);
                esc("a",0); text("------------------------------\n");
                text("MPT-II 58mm TEST PRINT\n");
                text("Bluetooth / ESC-POS OK\n");
                text(new SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.US).format(new Date())+"\n");
                text("------------------------------\n\n\n");
                runOnUiThread(()->toast("Test print भेज दिया"));
            }catch(Exception e){runOnUiThread(()->toast("Print error: "+e.getMessage()));}
        }).start();
    }

    private void printBill(){
        if(items.isEmpty()){toast("कम से कम 1 item जोड़ें");return;}
        if(!ensureConnected())return;
        String cust=customer.getText().toString().trim();
        String ph=phone.getText().toString().trim();
        final long currentBill=billNo;
        new Thread(()->{
            try{
                esc("@");
                esc("a",1); esc("E",1); text("MS COLLECTION\n"); esc("E",0);
                esc("a",0);
                text("Bill No: "+currentBill+"\n");
                text("Date: "+new SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.US).format(new Date())+"\n");
                if(!cust.isEmpty())text("Customer: "+cust+"\n");
                if(!ph.isEmpty())text("Mobile: "+ph+"\n");
                text("--------------------------------\n");
                text(String.format(Locale.US,"%-15s %4s %7s\n","ITEM","QTY","AMOUNT"));
                text("--------------------------------\n");
                double total=0;
                for(Item x:items){
                    String n=x.name.length()>15?x.name.substring(0,15):x.name;
                    text(String.format(Locale.US,"%-15s %4s %7s\n",n,money(x.qty),money(x.total())));
                    total+=x.total();
                }
                text("--------------------------------\n");
                esc("E",1); text(String.format(Locale.US,"TOTAL: ₹%s\n",money(total))); esc("E",0);
                text("--------------------------------\n");
                esc("a",1); text("Thank You!\n\n\n");
                runOnUiThread(()->{
                    billNo++;
                    prefs.edit().putLong("billNo",billNo).apply();
                    billNoText.setText("Bill No: "+billNo);
                    toast("Bill printed");
                });
            }catch(Exception e){runOnUiThread(()->toast("Print error: "+e.getMessage()));}
        }).start();
    }

    private void newBill(){
        items.clear(); customer.setText(""); phone.setText("");
        refreshItems(); toast("New bill ready");
    }

    private void esc(String command){
        try{out.write(new byte[]{0x1B,command.getBytes(StandardCharsets.US_ASCII)[0]});}catch(Exception ignored){}
    }
    private void esc(String command,int value){
        try{out.write(new byte[]{0x1B,command.getBytes(StandardCharsets.US_ASCII)[0],(byte)value});}catch(Exception ignored){}
    }
    private void text(String s)throws Exception{out.write(s.getBytes(StandardCharsets.UTF_8));}

    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    @Override protected void onDestroy(){
        super.onDestroy();
        try{if(socket!=null)socket.close();}catch(Exception ignored){}
    }
}
